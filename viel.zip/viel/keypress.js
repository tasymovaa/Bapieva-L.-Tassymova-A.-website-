var audio = new Audio("song.mp3");
audio.play();
